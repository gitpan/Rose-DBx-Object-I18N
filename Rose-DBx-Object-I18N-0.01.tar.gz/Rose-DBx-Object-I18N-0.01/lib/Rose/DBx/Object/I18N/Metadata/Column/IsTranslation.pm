package Rose::DBx::Object::I18N::Metadata::Column::IsTranslation;

use base 'Rose::DB::Object::Metadata::Column::Scalar';

sub type { return 'i18n_is_translation' }

1;
