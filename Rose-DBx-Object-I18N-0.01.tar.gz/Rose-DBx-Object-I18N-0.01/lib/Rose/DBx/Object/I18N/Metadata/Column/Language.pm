package Rose::DBx::Object::I18N::Metadata::Column::Language;

use base 'Rose::DB::Object::Metadata::Column::Scalar';

sub type { return 'i18n_language' }

1;
